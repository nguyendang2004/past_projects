package Lab13_Qifan_Group1_A2.database;

public enum UserType {
    WIZARD,
    ADMIN,
    REGISTERED_USER,
    GUEST
}
